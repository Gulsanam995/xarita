import React from 'react'
import Pets from './Pets';
import './App.css';
import './index'
import SearchParams from './SearchParams';

const App = () => {
  return (
    <div className='App'>
      <h1>Adopt Me!</h1>
      <SearchParams />
      <Pets />
    </div>
  )
}

export default App
